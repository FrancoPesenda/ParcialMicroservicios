INSERT INTO movies(name, genre, url_stream) VALUES('Dark Shadows', 'Terror', 'https://www.netflix.com/title/70217909');
INSERT INTO movies(name, genre, url_stream) VALUES('Gremlins', 'Terror', 'https://www.netflix.com/title/562050');
INSERT INTO movies(name, genre, url_stream) VALUES('Minions', 'Comedy', 'https://www.netflix.com/title/80033394');
INSERT INTO movies(name, genre, url_stream) VALUES('World War Z', 'Terror', 'https://www.netflix.com/title/70262639');
INSERT INTO movies(name, genre, url_stream) VALUES('Kung-fu Panda', 'Comedy', 'https://www.netflix.com/title/70075480');
INSERT INTO movies(name, genre, url_stream) VALUES('Pacific Rim', 'Action', 'https://www.netflix.com/title/70267241');
INSERT INTO movies(name, genre, url_stream) VALUES('The Old Guard', 'Action', 'https://www.netflix.com/title/81038963');
INSERT INTO movies(name, genre, url_stream) VALUES('Pride & Prejudice', 'Romance', 'https://www.netflix.com/title/70032594');
